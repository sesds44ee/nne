import os


class Mody(object):
    ELHYBA = os.environ.get("ELHYBA", "")
    
    OWNER = os.environ.get("OWNER", "6581896306")
    
    ID_BOT = int(os.environ.get("ID_BOT", ""))
    
    USER_BOT = os.environ.get("USER_BOT", "")
    
    MAX_ACCOUNTS = int(os.environ.get("MAX_ACCOUNTS", ""))
    
    API_ID = os.environ.get("API_ID", "25281175")
    
    API_HASH = os.environ.get("API_HASH", "6d99cb2b60a2c519fc1f99bd19565730")
    

